# Ejemplo de output · Offer Doc con IA

> Datos ficticios. Florencia, ex coordinadora de operaciones en un programa high ticket, arma su oferta de consultoría freelance (modo consultoría). Su portafolio tiene 8 piezas: 5 sobre el negocio donde trabajó (anonimizadas) y 3 sobre un caso práctico.

---

# Sistema Operativo en 6 Semanas · Florencia Ríos

**Yo ayudo a** founders de programas high ticket que venden por llamada **a** saber cada lunes cuánto vendieron, cuánto cobraron y qué cuotas vencen **sin** contratar más gente ni depender de la memoria de nadie, **a través de** un sistema operativo armado en 6 semanas: diagnóstico, CRM con cobros, tablero y reporte semanal.

## Para quién es

Programas online de USD 1.000 a 5.000 que se venden por llamada, con setters y closers, que facturan entre USD 20.000 y 100.000 por mes y donde el founder todavía aprueba casi todo.

## El problema que resuelvo

- **"Me entero de que no pagó cuando ya se fue."** Las cuotas vencidas se descubren tarde y se cobran mal.
- **"Cada closer tiene su planilla y a fin de mes nadie coincide."** Las ventas y las comisiones se discuten todos los meses.
- **"No sé qué canal me trae a los que compran."** La pauta se decide a ojo.

## Cómo se ve el resultado

| Antes | Después |
|---|---|
| El founder pregunta por WhatsApp cuánto se vendió | El lunes a las 9 recibe 5 números y 2 decisiones |
| Cuotas vencidas que nadie sigue | Cada cuota vencida tiene responsable el mismo día |
| Una planilla por closer | Un solo CRM con canal de origen y cobros separados |

## Cómo trabajo

1. **Diagnóstico (semana 1)** · Relevo herramientas, números y al equipo. Te entrego el Mapa de Diagnóstico Operativo con los 3 primeros movimientos.
2. **Centralización (semanas 2 y 3)** · Armo el CRM de ventas y cobros, migro las planillas y capacito al equipo.
3. **Tablero y alertas (semanas 4 y 5)** · Tablero con los 5 números que importan y alertas de cuota por vencer y vencida.
4. **Rutina (semana 6)** · Reporte semanal corriendo y SOPs de los 3 procesos clave. Te lo dejo funcionando sin mí.

## Qué te llevás

- Mapa de Diagnóstico Operativo
- CRM de ventas y cobros (Airtable), con vistas por rol
- Tablero de 5 números con su ficha
- Protocolo de cuota vencida
- 3 SOPs (onboarding, handoff de venta a servicio, cierre de mes)
- Reporte semanal de ops corriendo 2 semanas

## Qué no incluye

- Gestión de la pauta ni contenido.
- Atención a alumnos ni soporte diario.
- Automatizaciones complejas entre más de 3 herramientas (se cotizan aparte).

## Para quién no es

- Negocios que todavía no venden (primero hay que vender).
- Founders que no van a dar acceso a los números.
- Quien busca que alguien opere el día a día por él.

## Preguntas frecuentes

**"Ya probamos con un CRM y nadie lo usó."** Por eso el CRM se arma después del diagnóstico y con el equipo, no antes. La semana 6 es para que quede la rutina, no sólo la herramienta.

**"No tengo tiempo para esto."** Te pido 2 horas la semana 1 y 30 minutos por semana después. El resto lo hago yo con tu equipo.

**"¿Tenés experiencia con negocios como el mío?"** Coordiné operaciones dos años en un programa high ticket con setters y closers. Cuando armé el CRM de cobros, aparecieron 14 cuotas vencidas que nadie seguía, por unos USD 9.800, y en dos meses se recuperó la mitad. Te muestro el portafolio (los casos están anonimizados).

## Inversión

Desde USD 1.800 por las 6 semanas. El número exacto sale de la propuesta, después de la llamada de diagnóstico.

## Cómo empezamos

Una llamada de diagnóstico de 30 minutos. Te llevás tu Mapa de Fricción con las 5 cosas que más te cuestan por semana, trabajemos juntos o no.

---

## Tus Cinco Ps (para revisar cada trimestre · no va en la página)

| P | Tu respuesta |
|---|---|
| Persona | Founder de programa high ticket por llamada, USD 20.000–100.000/mes, con setters y closers |
| Promesa | Saber cada lunes cuánto vendió, cobró y qué vence, sin sumar gente |
| Problema | Cuotas vencidas tarde · planillas por closer · pauta a ojo |
| Path | Diagnóstico → Centralización → Tablero y alertas → Rutina (6 semanas) |
| Plataforma | Corta: LinkedIn · Larga: casos escritos en su web · Canal principal: referidos de ex compañeros |

**Test de una frase:** mostráselo a alguien de afuera del programa y preguntale qué hacés. Si no lo puede decir en una frase, ajustá el "Yo ayudo a".

**Tu frase, en dos versiones:**
- Bio: *Ordeno ventas y cobros de programas high ticket. Sistema operativo en 6 semanas.*
- En voz alta: *"Ayudo a founders de programas que se venden por llamada a saber cada lunes cuánto vendieron y cobraron, sin sumar gente."*

---

## Otro nicho, en corto (para no copiar el molde)

> Datos ficticios. Nicolás armó su portafolio sobre un caso práctico de membresía; no tiene clientes todavía. Contestó "no lo sé" a los plazos y a la plataforma.

**Yo ayudo a** founders de membresías de 300 a 2.000 miembros **a** ver venir las bajas antes de que pasen **sin** sumar otra persona al soporte, **a través de** un sistema de retención en 3 pasos: diagnóstico de bajas, alertas de cobro fallido y rutina de la CSM.

| P | Su respuesta |
|---|---|
| Persona | Founder de membresía mensual (300 a 2.000 miembros) con una CSM desbordada |
| Promesa | Saber cada semana quién está por irse y recuperar los cobros fallidos |
| Problema | "Se van y no sé por qué" · cobros fallidos que nadie reintenta · la CSM contesta todo a mano |
| Path | Diagnóstico de bajas → Alertas de cobro → Rutina de la CSM · **[SUPUESTO: 5 semanas (1 + 2 + 2), confirmalo con lo que te llevó el caso]** |
| Plataforma | **[SUPUESTO: canal principal referidos · corta: LinkedIn · larga: un caso escrito por mes, confirmalo]** |

**Experiencia, dicha como es, con un número que encontró él:** "Lo armé de punta a punta sobre un caso de práctica de una membresía así. En ese caso encontré 38 cobros fallidos de un mes que nadie había reintentado. Te muestro lo que hice."

**Para confirmar:** los plazos y la plataforma (elegí una corta y una larga, no más).

**Medir los plazos en 5 minutos.** Nicolás no los había medido. Mirando las fechas de sus archivos del caso reconstruye: diagnóstico de bajas 8 h, alertas de cobro 14 h, rutina de la CSM 6 h = 28 h. Ajuste por negocio real *(orientativo: × 1,5 a 2)*: 42 a 56 h. Le puede dar 10 h por semana a un cliente → **entre 5 y 6 semanas**. Lo confirma.

En la **versión limpia** (la misma página sin ninguna marca [SUPUESTO], lista para mandar), "Cómo trabajo" queda así: *"Tres pasos, entre 5 y 6 semanas. El diagnóstico de bajas te lo entrego en la primera semana; el plazo exacto va en la propuesta, según el tamaño de tu membresía."*
